#ifndef H
#define H

#include <vector>
#include <map>
#include <string>
#include "Animals/Animal.h"

using namespace std;

class AbstractAnimalCreator {
	public:
	virtual Animal* create(string _name) = 0;
};

template <class Type>
class AnimalCreator : public AbstractAnimalCreator {
	public:
	Animal* create(string _name) {
		return new Type(_name);
	}
};

class AnimalFactory {

	private:

	static map<string, AbstractAnimalCreator*> reg;

	AnimalFactory() {}
	AnimalFactory(const AnimalFactory&);

	public:

	static int registerAnimal(string id, AbstractAnimalCreator *creator) {
		reg[id] = creator;
		return 0;
	}

	static Animal* produce(string *id, string *name) {
		return reg[*id]->create(*name);
	}

};

#endif
