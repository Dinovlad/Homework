#include <iostream>
#include <string>
#include <vector>
#include <map>

using namespace std;

void func() {

	int x = 0;

	x++;

	cout << x << endl;

}

void statFunc() {

	static int x = 0;

	x++;

	cout << x << endl;

}

class singletone {
private:

	int x = 0;

	singletone() {}

	singletone(const singletone&);

public:

	static singletone& getSingletone() {
		static singletone s;
		return s;
	}


	void p() {
		x++;
		cout << x << endl;
	};

};

int main() {

	singletone::getSingletone().p();
	singletone::getSingletone().p();

	return 0;

}
